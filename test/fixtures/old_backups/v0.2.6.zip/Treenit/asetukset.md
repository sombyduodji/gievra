---
name: 
theme: system
weightStep: 2,5
tips: true
body_tracker: false
sports: false
mode: gym
move_names: fi
watch: false
rest_timer: false
rest_sound: pling
rest_adjust: 0, 0, 0
deloadEvery: 6
introDone: true
---

# Gievran asetukset

Tämän tiedoston voi muokata käsin. Sovellus lukee sen käynnistyessään.

## Lämmittelylaitteet
- 🚶 Kävelymatto
- 🚴 Kuntopyörä
- 🏃 Crosstrainer
- 🪜 Porraskone
- 🚣 Soutulaite
- 🧘 Venyttely

## Omat liikkeet

## Mittaustavat
- Oma veto: sekunnit

## Vammat
- niska

## Tauot
- 2026-10-20 – loma

### Selkä
- Oma veto
