---
goal: voimanosto
experience: keski
days: 4
minutes: 60
start: 2026-11-09
deloadEvery: 5
---

# Ohjelma: Voimanosto · 4 päivää viikossa

> 10 viikon sykli: 4 vk kasaus, kevennysviikko, 4 vk tehostus, huippu ja testi. Painot lasketaan arvioidusta maksimista (e1RM).
> Pisin treeni kestää noin 68 min. Pääliikkeiden tauot ovat pitkiä; lyhennä tarvittaessa lisäliikkeistä.
> Kevennysviikko joka 5. viikko (puolet sarjoista, painot −10 %).

## Kyykky
- Takakyykky | raskas | varaa 1–3 | tauko 4 min | KK
- Romanialainen maastaveto | 3 × 6–8 | varaa 1–3 | tauko 2,5 min | MAV
- Reiden ojennus | 2 × 10–12 | varaa 0–2 | tauko 1,5 min | POJ
- Pallof press | 2 × 10–15 | varaa 0–2 | tauko 1,5 min | KES

## Penkki raskas
- Penkkipunnerrus | raskas | varaa 1–3 | tauko 4 min | KP
- Käsipainosoutu | 4 × 6–10 | varaa 1–3 | tauko 2,5 min | VVE
- Pystypunnerrus | 2 × 6–8 | varaa 1–3 | tauko 2,5 min | PTY
- Ojentajapunnerrus taljassa | 2 × 10–12 | varaa 0–2 | tauko 1,5 min | OJE
- Face pull | 2 × 12–20 | varaa 0–2 | tauko 1,5 min | TAK

## Maastaveto
- Maastaveto | raskas | varaa 1–3 | tauko 4 min | KM
- Etukyykky | 3 × 5–8 | varaa 1–3 | tauko 2,5 min | KYV
- Reiden koukistus | 3 × 10–12 | varaa 0–2 | tauko 1,5 min | POK
- Farmer walk | 3 × 1–2 | varaa 0–2 | tauko 1,5 min | KAN

## Penkki volyymi
- Penkkipunnerrus | volyymi | varaa 1–3 | tauko 4 min | KP
- Taukopenkki | 2 × 6–8 | varaa 1–3 | tauko 2,5 min | PEV
- Leuanveto | 4 × 8–10 | varaa 1–3 | tauko 2,5 min | PVE
- Face pull | 4 × 15 | varaa 0–2 | tauko 1,5 min | TAK
